/**
 * 打印管理
 * @param {String} t
 */
export default function log(t) {
	console.log(t);	// 若不想打印内容请注释
}
