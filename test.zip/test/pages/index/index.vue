<template>
	<view class="bg">
		<view class="portrait">
			<img src="../../static/Y.jpg" alt="">
			<img src="../../static/7.jpg" alt="">
		</view>
		<view class="container">
			已经在一起{{DateTime}}啦！
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				href: 'https://uniapp.dcloud.io/component/README?id=uniui',
				DateTime : ''
			}
		},
		onLoad () {
			this.Time()
		},
		methods: {
			Time(){
				let timer = new Date('2021-04-15 00:00:00')
				let d = new Date()
				let time = d - timer
				let days = Math.floor(time / (24 * 3600 * 1000));
				let leavel = time % (24 * 3600 * 1000); // 计算天数后剩余的时间
				let hours = Math.floor(leavel / (3600 * 1000)); // 计算剩余的小时数
				let leavel2 = leavel % (3600 * 1000); // 计算剩余小时后剩余的毫秒数
				let minutes = Math.floor(leavel2 / (60 * 1000)); // 计算剩余的分钟数
				let leave3 = leavel2 % ( 60 * 1000 )      //计算分钟数后剩余的毫秒数
				let seconds=Math.round(leave3/1000)
				this.DateTime = days + '天' + hours + '时' + minutes + '分' + seconds + '秒'
			},
		},
		mounted () {
			this.DateTime = setInterval(this.Time, 1000);
		}
	}
</script>

<style>
	html {
		width: 100%;
		height: 100%;
	}
	body {
		width: 100%;
		height: 100%;
	}
	.bg {
		width: 100%;
		height: 100%;
		background-image: url(../../static/index-bg.jpg);
		background-size: 100% 100%;
	}
	uni-page-body {
		height: 100%;
	}
	.container {
		padding: 20px;
		font-size: 20px;
		line-height: 24px;
		text-align: center;
	}
	.portrait {
		display: flex;
		justify-content:space-evenly;
		height: 35%;
		align-items: flex-end;
	}
	.portrait img{
		width: 150rpx;
		height: 150rpx;
		border-radius: 50%;
	}
</style>
