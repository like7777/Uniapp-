<template>
	<view id="content">
		<textarea type="text" v-model="value"  placeholder="在这里写一封信寄给我吧!" class="input" maxlength="-1"/>
		<button type="default" class="btn" @click="btn()">发送</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value : ""
			}
		},
		methods: {
			btn(){
				console.log(this.value)
			}
		}
	}
</script>

<style>
	html {
		width: 100%;
		height: 100%;
	}
	body {
		width: 100%;
		height: 100%;
	}
	uni-page-body {
		height: 100%;
	}
	#content {
		height: 100%;
		padding-top: 100rpx;
	}
	.input {
		border: #ccc solid 1px;
		width: 80%;
		height: 20%;
		margin: 0 auto;
		font-size: 16px;
	}
	.btn {
		margin-top: 50rpx;
		background: #0095ff;
		width: 100%;
	}
</style>
