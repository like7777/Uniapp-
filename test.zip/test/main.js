import Vue from 'vue'
import App from './App'
import inputs from './components/QuShe-inputs/inputs.vue';

Vue.component('inputs', inputs);
Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()
